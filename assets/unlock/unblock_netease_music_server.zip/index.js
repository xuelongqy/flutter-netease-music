const http = require('http');
const url  = require('url');
const match = require('@nondanee/unblockneteasemusic')

let server = http.createServer( (request, response) => {
    let urlObject = url.parse(request.url, true);
    let pathname = urlObject.pathname
    let query = urlObject.query

    if (pathname === '/match') {
        let id = query.id
        if (id) {
            match(id, ['qq', 'kuwo', 'migu']).then((data) => {
                if (data) {
                    response.end(JSON.stringify(data));
                } else {
                    response.end('{}');
                }
            }).catch((e) => {
                response.end('{}');
            })
        } else {
            response.end('{}');
        }
    } else {
        response.end(pathname);
    }
});
server.listen(1371);